"""
Instagram Publishing Service
SRS Reference: Part 3 Sec 25 (Publishing Service), Part 3 Sec 48 (Instagram Integration)

Uses Meta's Graph API to publish images to an Instagram Business/Creator account.
This requires setup steps ONLY a human can do (see README "Phase 2 Setup" section):
  1. Convert Instagram account to Business or Creator
  2. Link it to a Facebook Page
  3. Create a Meta Developer App at developers.facebook.com
  4. Get an Instagram-scoped access token with instagram_content_publishing permission
  5. Get your Instagram Business Account ID

Publishing is a TWO-STEP process per Meta's API:
  1. Create a media container (upload image, get a container ID back)
  2. Publish that container (turns it into a live post)

This module assumes the image is already publicly accessible via a URL, since Meta's
API fetches the image FROM a URL rather than accepting direct file uploads. This is why
the FastAPI app serves images at /static/ - that URL gets passed to Meta.

IMPORTANT: this has NOT been tested against the live Meta API (sandbox has no network
access). The request format below matches Meta's official Graph API documentation as of
this writing, but Meta does change API versions/requirements over time - if a call fails,
check https://developers.facebook.com/docs/instagram-platform/content-publishing for the
current required fields, and bring the exact error back to this chat.
"""

import os
import time
import requests
from dataclasses import dataclass
from typing import Optional

GRAPH_API_VERSION = "v21.0"
GRAPH_API_BASE = f"https://graph.facebook.com/{GRAPH_API_VERSION}"

IG_ACCESS_TOKEN = os.environ.get("IG_ACCESS_TOKEN", "")
IG_BUSINESS_ACCOUNT_ID = os.environ.get("IG_BUSINESS_ACCOUNT_ID", "")


@dataclass
class PublishResult:
    success: bool
    post_id: Optional[str] = None
    error: Optional[str] = None


def _check_credentials():
    if not IG_ACCESS_TOKEN or not IG_BUSINESS_ACCOUNT_ID:
        raise RuntimeError(
            "Instagram credentials not configured. Set IG_ACCESS_TOKEN and "
            "IG_BUSINESS_ACCOUNT_ID environment variables. See README 'Phase 2 Setup'."
        )


def _create_media_container(image_url: str, caption: str = "") -> Optional[str]:
    """
    Step 1 of 2: Tell Meta to fetch the image from image_url and prepare it as a post.
    Returns a container ID to be used in the publish step.
    """
    url = f"{GRAPH_API_BASE}/{IG_BUSINESS_ACCOUNT_ID}/media"
    payload = {
        "image_url": image_url,
        "caption": caption,
        "access_token": IG_ACCESS_TOKEN,
    }

    resp = requests.post(url, data=payload, timeout=30.0)

    if resp.status_code != 200:
        print(f"[instagram_publisher] Container creation failed: {resp.status_code} - {resp.text[:300]}")
        return None

    data = resp.json()
    return data.get("id")


def _wait_for_container_ready(container_id: str, max_attempts: int = 10, delay_seconds: int = 3) -> bool:
    """
    Meta processes the image asynchronously. We poll the container's status_code
    until it's FINISHED before attempting to publish, per Meta's documented flow.
    """
    url = f"{GRAPH_API_BASE}/{container_id}"
    params = {"fields": "status_code", "access_token": IG_ACCESS_TOKEN}

    for attempt in range(max_attempts):
        resp = requests.get(url, params=params, timeout=15.0)
        if resp.status_code == 200:
            status = resp.json().get("status_code")
            if status == "FINISHED":
                return True
            if status == "ERROR":
                print(f"[instagram_publisher] Container processing failed for {container_id}")
                return False
        time.sleep(delay_seconds)

    print(f"[instagram_publisher] Container {container_id} did not finish processing in time.")
    return False


def _publish_container(container_id: str) -> Optional[str]:
    """Step 2 of 2: Publish the prepared container, making it a live Instagram post."""
    url = f"{GRAPH_API_BASE}/{IG_BUSINESS_ACCOUNT_ID}/media_publish"
    payload = {
        "creation_id": container_id,
        "access_token": IG_ACCESS_TOKEN,
    }

    resp = requests.post(url, data=payload, timeout=30.0)

    if resp.status_code != 200:
        print(f"[instagram_publisher] Publish failed: {resp.status_code} - {resp.text[:300]}")
        return None

    return resp.json().get("id")


def publish_meme_to_instagram(image_url: str, caption: str = "") -> PublishResult:
    """
    Main entry point. SRS Part 1 Sec 8: 'Publishing Service posts to Instagram.'

    image_url must be a PUBLICLY ACCESSIBLE https URL (Meta fetches it server-side).
    This means your deployed app's /static/ URL, not a local file path.
    """
    try:
        _check_credentials()
    except RuntimeError as e:
        return PublishResult(success=False, error=str(e))

    container_id = _create_media_container(image_url, caption)
    if not container_id:
        return PublishResult(success=False, error="Failed to create media container")

    ready = _wait_for_container_ready(container_id)
    if not ready:
        return PublishResult(success=False, error="Media container did not finish processing")

    post_id = _publish_container(container_id)
    if not post_id:
        return PublishResult(success=False, error="Failed to publish container")

    return PublishResult(success=True, post_id=post_id)


if __name__ == "__main__":
    # Manual test - requires real IG credentials and a real publicly-hosted image URL
    result = publish_meme_to_instagram(
        image_url="https://your-deployed-app.up.railway.app/static/meme_example.png",
        caption="Test post from MemePulse AI 🤖",
    )
    print(result)
