"""
Database Layer
SRS Reference: Part 4 (Database Schema) - simplified to SQLite for zero-config deployment.

SQLite is used instead of PostgreSQL for Phase 1 because:
- Zero setup (no separate DB server to configure/pay for)
- Single file, easy backup, fine for single-user MVP scale
- SRS's own architecture treats the DB as swappable behind a data layer (Part 4 Sec 35)
- Migration to Postgres later (Part 4 spec) is straightforward if/when scale demands it

Tables map to SRS Part 4 Sec 35.4 (Trends) and 35.5 (Meme Ideas), with a
'status' field added for the human review workflow (approve/reject before posting).
"""

import sqlite3
import os
from datetime import datetime, timezone
from contextlib import contextmanager
from typing import Optional, List, Dict, Any

_DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(_DB_DIR, "memepulse.sqlite3"))


SCHEMA = """
CREATE TABLE IF NOT EXISTS memes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trend_title TEXT NOT NULL,
    trend_category TEXT,
    trend_url TEXT,
    caption_top TEXT NOT NULL,
    caption_bottom TEXT,
    humor_style TEXT,
    confidence_score REAL,
    originality_score REAL,
    image_path TEXT,
    status TEXT NOT NULL DEFAULT 'pending',  -- pending | approved | rejected | posted
    created_at TEXT NOT NULL,
    reviewed_at TEXT,
    posted_at TEXT,
    instagram_post_id TEXT
);

CREATE INDEX IF NOT EXISTS idx_memes_status ON memes(status);
CREATE INDEX IF NOT EXISTS idx_memes_created ON memes(created_at);
"""


@contextmanager
def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_db() as conn:
        conn.executescript(SCHEMA)


def insert_meme(
    trend_title: str,
    caption_top: str,
    caption_bottom: str = "",
    trend_category: str = "",
    trend_url: str = "",
    humor_style: str = "",
    confidence_score: float = 0.0,
    originality_score: float = 0.0,
    image_path: str = "",
) -> int:
    """Inserts a newly generated meme idea with status='pending' for human review."""
    with get_db() as conn:
        cursor = conn.execute(
            """
            INSERT INTO memes (
                trend_title, trend_category, trend_url, caption_top, caption_bottom,
                humor_style, confidence_score, originality_score, image_path,
                status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)
            """,
            (
                trend_title, trend_category, trend_url, caption_top, caption_bottom,
                humor_style, confidence_score, originality_score, image_path,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        return cursor.lastrowid


def get_memes(status: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    """Fetches memes, optionally filtered by status. Most recent first."""
    with get_db() as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM memes WHERE status = ? ORDER BY created_at DESC LIMIT ?",
                (status, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM memes ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(row) for row in rows]


def get_meme_by_id(meme_id: int) -> Optional[Dict[str, Any]]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM memes WHERE id = ?", (meme_id,)).fetchone()
        return dict(row) if row else None


def update_meme_status(meme_id: int, status: str) -> bool:
    """Updates status to 'approved' or 'rejected' after human review."""
    valid_statuses = {"pending", "approved", "rejected", "posted"}
    if status not in valid_statuses:
        raise ValueError(f"Invalid status: {status}")

    with get_db() as conn:
        cursor = conn.execute(
            "UPDATE memes SET status = ?, reviewed_at = ? WHERE id = ?",
            (status, datetime.now(timezone.utc).isoformat(), meme_id),
        )
        return cursor.rowcount > 0


def mark_posted(meme_id: int, instagram_post_id: str = "") -> bool:
    """Called after successful Instagram publish (Phase 2)."""
    with get_db() as conn:
        cursor = conn.execute(
            "UPDATE memes SET status = 'posted', posted_at = ?, instagram_post_id = ? WHERE id = ?",
            (datetime.now(timezone.utc).isoformat(), instagram_post_id, meme_id),
        )
        return cursor.rowcount > 0


def get_stats() -> Dict[str, int]:
    """Basic counts for the dashboard header. SRS Part 4 Sec 35.8 (Analytics) - simplified."""
    with get_db() as conn:
        rows = conn.execute(
            "SELECT status, COUNT(*) as cnt FROM memes GROUP BY status"
        ).fetchall()
        stats = {row["status"]: row["cnt"] for row in rows}
        stats["total"] = sum(stats.values())
        return stats
